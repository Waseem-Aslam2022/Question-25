function Validation() {
    var characterString = document.getElementById("Name").value;
    if (characterString.length > 50) {
        document.getElementById("nameError").innerHTML = "Character Limit Exceeds";
    }
    else if (characterString.length == 0) {
        document.getElementById("nameError").innerHTML = "Name cannot be empty";
    }
    else {
        document.getElementById("nameError").innerHTML = "";
    }

    var characterString = document.getElementById("Email").value;
    if (characterString.length < 1) {
        document.getElementById("EmailError").innerHTML = "Email cannot be empty";
    }
    else 
    {
        let Flag = 0;
        for (let i = 0; i < characterString.length; i++) {
            if (characterString[i] == '@') {
                Flag = 1;
            }
        }
        if (Flag != 1|| characterString[0] == '@' || characterString[characterString.length - 1] == '@') {
            document.getElementById("EmailError").innerHTML = "Invalid email";
        }
        else {
            document.getElementById("EmailError").innerHTML = "";
        }
    }

    var characterString = document.getElementById("DOB").value;

    if (characterString == "") {
        document.getElementById("DOBError").innerHTML = "DOB cannot be empty";
    }
    else {
        var todayDate = new Date();
        var birthDate = new Date(characterString);
        var age = todayDate.getFullYear() - birthDate.getFullYear();
        var month = todayDate.getMonth() - birthDate.getMonth();
        if (month < 0 || (month === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
    
        
        if (age <= 13) {
            document.getElementById("DOBERROR").innerHTML = "Hello Kid! You are too young for this";
        }

    }

    characterString = document.getElementById("Field").value;
    if (characterString == "") {
        document.getElementById("FieldError").innerHTML = "Please Select one preference";
    }


}